sum = 0
for a in range(1,101):
    sum += a
print(sum)